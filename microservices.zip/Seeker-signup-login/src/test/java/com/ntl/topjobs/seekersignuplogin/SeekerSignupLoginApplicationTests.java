package com.ntl.topjobs.seekersignuplogin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
//@SpringBootTest
public class SeekerSignupLoginApplicationTests {

	@Test
	public void contextLoads() {
	}

}
